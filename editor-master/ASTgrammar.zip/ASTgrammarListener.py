# Generated from ASTgrammar.g4 by ANTLR 4.7.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ASTgrammarParser import ASTgrammarParser
else:
    from ASTgrammarParser import ASTgrammarParser

# This class defines a complete listener for a parse tree produced by ASTgrammarParser.
class ASTgrammarListener(ParseTreeListener):

    # Enter a parse tree produced by ASTgrammarParser#t.
    def enterT(self, ctx:ASTgrammarParser.TContext):
        pass

    # Exit a parse tree produced by ASTgrammarParser#t.
    def exitT(self, ctx:ASTgrammarParser.TContext):
        pass


    # Enter a parse tree produced by ASTgrammarParser#n.
    def enterN(self, ctx:ASTgrammarParser.NContext):
        pass

    # Exit a parse tree produced by ASTgrammarParser#n.
    def exitN(self, ctx:ASTgrammarParser.NContext):
        pass


    # Enter a parse tree produced by ASTgrammarParser#l.
    def enterL(self, ctx:ASTgrammarParser.LContext):
        pass

    # Exit a parse tree produced by ASTgrammarParser#l.
    def exitL(self, ctx:ASTgrammarParser.LContext):
        pass


    # Enter a parse tree produced by ASTgrammarParser#c.
    def enterC(self, ctx:ASTgrammarParser.CContext):
        pass

    # Exit a parse tree produced by ASTgrammarParser#c.
    def exitC(self, ctx:ASTgrammarParser.CContext):
        pass


    # Enter a parse tree produced by ASTgrammarParser#txt.
    def enterTxt(self, ctx:ASTgrammarParser.TxtContext):
        pass

    # Exit a parse tree produced by ASTgrammarParser#txt.
    def exitTxt(self, ctx:ASTgrammarParser.TxtContext):
        pass


