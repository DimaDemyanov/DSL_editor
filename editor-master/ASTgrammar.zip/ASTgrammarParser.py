# Generated from ASTgrammar.g4 by ANTLR 4.7.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\r")
        buf.write(":\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\3\2\3\2\3\2")
        buf.write("\3\2\3\2\7\2\22\n\2\f\2\16\2\25\13\2\3\2\3\2\3\3\3\3\3")
        buf.write("\3\7\3\34\n\3\f\3\16\3\37\13\3\3\3\3\3\3\4\3\4\3\4\7\4")
        buf.write("&\n\4\f\4\16\4)\13\4\3\4\3\4\3\5\3\5\3\5\3\5\3\5\3\5\3")
        buf.write("\6\3\6\7\6\65\n\6\f\6\16\68\13\6\3\6\2\2\7\2\4\6\b\n\2")
        buf.write("\2\28\2\f\3\2\2\2\4\30\3\2\2\2\6\"\3\2\2\2\b,\3\2\2\2")
        buf.write("\n\62\3\2\2\2\f\r\7\3\2\2\r\23\5\4\3\2\16\17\5\6\4\2\17")
        buf.write("\20\5\2\2\2\20\22\3\2\2\2\21\16\3\2\2\2\22\25\3\2\2\2")
        buf.write("\23\21\3\2\2\2\23\24\3\2\2\2\24\26\3\2\2\2\25\23\3\2\2")
        buf.write("\2\26\27\7\4\2\2\27\3\3\2\2\2\30\31\7\5\2\2\31\35\5\n")
        buf.write("\6\2\32\34\5\b\5\2\33\32\3\2\2\2\34\37\3\2\2\2\35\33\3")
        buf.write("\2\2\2\35\36\3\2\2\2\36 \3\2\2\2\37\35\3\2\2\2 !\7\6\2")
        buf.write("\2!\5\3\2\2\2\"#\7\7\2\2#\'\5\n\6\2$&\5\b\5\2%$\3\2\2")
        buf.write("\2&)\3\2\2\2\'%\3\2\2\2\'(\3\2\2\2(*\3\2\2\2)\'\3\2\2")
        buf.write("\2*+\7\b\2\2+\7\3\2\2\2,-\7\t\2\2-.\5\n\6\2./\7\n\2\2")
        buf.write("/\60\5\n\6\2\60\61\7\13\2\2\61\t\3\2\2\2\62\66\7\r\2\2")
        buf.write("\63\65\7\r\2\2\64\63\3\2\2\2\658\3\2\2\2\66\64\3\2\2\2")
        buf.write("\66\67\3\2\2\2\67\13\3\2\2\28\66\3\2\2\2\6\23\35\'\66")
        return buf.getvalue()


class ASTgrammarParser ( Parser ):

    grammarFileName = "ASTgrammar.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "'['", "']'", "'<'", "'>'", 
                     "'{'", "'='", "'}'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "SPACE", "SYMBOL" ]

    RULE_t = 0
    RULE_n = 1
    RULE_l = 2
    RULE_c = 3
    RULE_txt = 4

    ruleNames =  [ "t", "n", "l", "c", "txt" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    SPACE=10
    SYMBOL=11

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class TContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def n(self):
            return self.getTypedRuleContext(ASTgrammarParser.NContext,0)


        def l(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASTgrammarParser.LContext)
            else:
                return self.getTypedRuleContext(ASTgrammarParser.LContext,i)


        def t(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASTgrammarParser.TContext)
            else:
                return self.getTypedRuleContext(ASTgrammarParser.TContext,i)


        def getRuleIndex(self):
            return ASTgrammarParser.RULE_t

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterT" ):
                listener.enterT(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitT" ):
                listener.exitT(self)




    def t(self):

        localctx = ASTgrammarParser.TContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_t)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 10
            self.match(ASTgrammarParser.T__0)
            self.state = 11
            self.n()
            self.state = 17
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==ASTgrammarParser.T__4:
                self.state = 12
                self.l()
                self.state = 13
                self.t()
                self.state = 19
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 20
            self.match(ASTgrammarParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def txt(self):
            return self.getTypedRuleContext(ASTgrammarParser.TxtContext,0)


        def c(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASTgrammarParser.CContext)
            else:
                return self.getTypedRuleContext(ASTgrammarParser.CContext,i)


        def getRuleIndex(self):
            return ASTgrammarParser.RULE_n

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterN" ):
                listener.enterN(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitN" ):
                listener.exitN(self)




    def n(self):

        localctx = ASTgrammarParser.NContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_n)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 22
            self.match(ASTgrammarParser.T__2)
            self.state = 23
            self.txt()
            self.state = 27
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==ASTgrammarParser.T__6:
                self.state = 24
                self.c()
                self.state = 29
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 30
            self.match(ASTgrammarParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def txt(self):
            return self.getTypedRuleContext(ASTgrammarParser.TxtContext,0)


        def c(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASTgrammarParser.CContext)
            else:
                return self.getTypedRuleContext(ASTgrammarParser.CContext,i)


        def getRuleIndex(self):
            return ASTgrammarParser.RULE_l

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterL" ):
                listener.enterL(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitL" ):
                listener.exitL(self)




    def l(self):

        localctx = ASTgrammarParser.LContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_l)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 32
            self.match(ASTgrammarParser.T__4)
            self.state = 33
            self.txt()
            self.state = 37
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==ASTgrammarParser.T__6:
                self.state = 34
                self.c()
                self.state = 39
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 40
            self.match(ASTgrammarParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def txt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASTgrammarParser.TxtContext)
            else:
                return self.getTypedRuleContext(ASTgrammarParser.TxtContext,i)


        def getRuleIndex(self):
            return ASTgrammarParser.RULE_c

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterC" ):
                listener.enterC(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitC" ):
                listener.exitC(self)




    def c(self):

        localctx = ASTgrammarParser.CContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_c)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 42
            self.match(ASTgrammarParser.T__6)
            self.state = 43
            self.txt()
            self.state = 44
            self.match(ASTgrammarParser.T__7)
            self.state = 45
            self.txt()
            self.state = 46
            self.match(ASTgrammarParser.T__8)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TxtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SYMBOL(self, i:int=None):
            if i is None:
                return self.getTokens(ASTgrammarParser.SYMBOL)
            else:
                return self.getToken(ASTgrammarParser.SYMBOL, i)

        def getRuleIndex(self):
            return ASTgrammarParser.RULE_txt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTxt" ):
                listener.enterTxt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTxt" ):
                listener.exitTxt(self)




    def txt(self):

        localctx = ASTgrammarParser.TxtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_txt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 48
            self.match(ASTgrammarParser.SYMBOL)
            self.state = 52
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==ASTgrammarParser.SYMBOL:
                self.state = 49
                self.match(ASTgrammarParser.SYMBOL)
                self.state = 54
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





